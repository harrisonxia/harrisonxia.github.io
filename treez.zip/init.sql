CREATE TABLE Customer (
     ID INT NOT NULL AUTO_INCREMENT,
     Email VARCHAR(40) NOT NULL UNIQUE,
     PRIMARY KEY (id)
);


CREATE TABLE Orders (
    OrderID INT NOT NULL AUTO_INCREMENT,
    Email VARCHAR(40),
    OrderDate TIMESTAMP NOT NULL,
    Status VARCHAR(30),
    CustomerID INT NOT NULL,
    PRIMARY KEY (OrderID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(ID),
    FOREIGN KEY (Email) REFERENCES Customer(Email)
);


CREATE TABLE Inventory (
    ProductID INT NOT NULL AUTO_INCREMENT,
    Name VARCHAR(40) NOT NULL,
    Price NUMERIC(10,1) NOT NULL,
    Description VARCHAR(255),
    Quantity INT NOT NULL,
    PRIMARY KEY (ProductID)
);

CREATE TABLE OrderDetail (
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Inventory(ProductID)
);

INSERT INTO Customer VALUES
(NULL, 'alex@gmail.com'),
(NULL, 'bob@gmail.com'),
(NULL, 'cilo@gmail.com'),
(NULL, 'dave@gmail.com'),
(NULL, 'emily@gmail.com');

INSERT INTO Orders VALUES
(NULL, 'alex@gmail.com', CURRENT_TIMESTAMP, 'placed', 1, 3.3),
(NULL, 'bob@gmail.com', CURRENT_TIMESTAMP, 'shipped', 2, 3.3),
(NULL, 'cilo@gmail.com', CURRENT_TIMESTAMP, 'placed', 3, 6.6),
(NULL, 'dave@gmail.com', CURRENT_TIMESTAMP, 'placed', 4, 11),
(NULL, 'emily@gmail.com', CURRENT_TIMESTAMP, 'placed', 5, 3.3);

INSERT INTO Inventory VALUES
(NULL, 'AAA', 1.1, 'this is product AAA', 5),
(NULL, 'BBB', 2.2, 'this is product BBB', 120),
(NULL, 'CCC', 3.3, 'this is product CCC', 120);

INSERT INTO OrderDetail VALUES
(1, 1, 1),
(1, 2, 1),
(2, 3, 1),
(3, 1, 1),
(3, 2, 1),
(3, 3, 1),
(4, 2, 5),
(5, 3, 1);