var express = require('express');
var router = express.Router();

router.use(function (req, res, next) {
    console.log(req.method, req.url);
    next();
});

var allInvenRouter = router.route('/');

// get all orders
allInvenRouter.get(function (req, res, next) {

    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        conn.query('SELECT * FROM Inventory', function (err, response) {
            if (err) {
                console.log(err);
                return next("Mysql error, check your query");
            }
            res.json(response);
        });

    });

});

// create a new inventory item
allInvenRouter.post(function (req, res, next) {
    // validation
    req.assert('name', 'A valid email is required').notEmpty();
    req.assert('price', 'A valid price is required').notEmpty();
    req.assert('quantity', 'A valid price is required').notEmpty();

    var errors = req.validationErrors();
    if (errors) {
        res.status(422).json(errors);
        return;
    }
    //get data
    var data = {
        name: req.body.name,
        price: req.body.price,
        quantity: req.body.quantity,
        description: req.body.description ? req.body.description : '',
    };

    //inserting into mysql
    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        var query = conn.query("INSERT INTO Inventory set ? ", data, function (err, rows) {

            if (err) {
                console.log(err);
                return next("Mysql error, check your query");
            }

            res.status(200).send('New inventory item was created!');
        });

    });
});

var singleInvenRouter = router.route('/:id');

async function getOneInventory(id, req) {
    return new Promise((resolve, reject) => {

        req.getConnection(function (err, conn) {

            if (err) return next("Cannot Connect");

            conn.query('SELECT * FROM Inventory WHERE ProductID=?', [id],
                function (err, response) {
                    if (err) {
                        console.log(err);
                        reject({ result: err });
                    }
                    // handling order not found
                    if (response.length === 0) {
                        reject({ result: 'Inventory ID not found' })
                    } else {
                        resolve({ result: response });
                    }
                });
        });
    });
}

singleInvenRouter.get(function (req, res, next) {
    var orderID = req.params.id;

    getOneInventory(orderID, req).then(result => {
        res.json(result.result);
    }).catch(err => {
        res.status(404).send('Inventory ID not found');
    })

});

async function updateOneInventory(id, data, req) {
    return new Promise((resolve, reject) => {
        req.getConnection(function (err, conn) {

            if (err) return next("Cannot Connect");

            var query = conn.query("UPDATE Inventory set ? WHERE ProductID = ?", [data, id], function (err, resp) {

                if (err) {
                    console.log(err);
                    reject({ result: err })
                }

                if (resp.affectedRows === 0) {
                    reject({ result: err })
                }
                resolve({ result: '200' })
            });
        });
    });
}

// update an item
singleInvenRouter.put(function (req, res, next) {
    var id = req.params.id;
    var errors = req.validationErrors();
    if (errors) {
        res.status(422).json(errors);
        return;
    }

    //get data
    var data = {};

    if (req.body.name) {
        data.name = req.body.name;
    }
    if (req.body.price) {
        data.price = req.body.price;
    }
    if (req.body.description) {
        data.description = req.body.description;
    }
    if (req.body.quantity) {
        data.quantity = req.body.quantity;
    }
    if (data === {}) {
        res.status(422).json(errors);
        return;
    }

    updateOneInventory(id, data, req).then(result => {
        res.status(200).send('Item was updated successfully!');
    }).catch(err => {
        res.status(404).send({ error: 'Product ID not found, make sure it\'s input correctly.' });
    })

});

// delete data
singleInvenRouter.delete(function (req, res, next) {

    var id = req.params.id;

    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        var query = conn.query("DELETE FROM Inventory WHERE ProductID = ? ", [id], function (err, resp) {

            if (err) {
                console.log(err);
                return next("Mysql error, check your query");
            }

            if (resp.affectedRows === 0) {
                res.status(404).send({ error: 'Product ID not found, make sure it\'s input correctly.' });
                return;
            }
            res.status(200).send('Item was deleted successfully!');
        });

    });
});

module.exports.router = router;

exports.getOneInventory = getOneInventory;
exports.updateOneInventory = updateOneInventory;
