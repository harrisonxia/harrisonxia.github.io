var express = require('express');
var router = express.Router();
var MOMENT = require('moment');
var inventories = require('./inventories');

router.use(function (req, res, next) {
    console.log(req.method, req.url);
    next();
});

var allOrderRouter = router.route('/');

// get all orders
allOrderRouter.get(function (req, res, next) {

    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        conn.query('SELECT * FROM Orders', function (err, response) {
            if (err) {
                console.log(err);
                return next("Mysql error, check your query");
            }
            res.json(response);
        });

    });

});

// create a new order
allOrderRouter.post(async function (req, res, next) {
    // validation
    req.assert('email', 'A valid email is required').isEmail();

    var errors = req.validationErrors();
    if (errors) {
        res.status(422).json(errors);
        return;
    }
    Promise.all(req.body.OrderDetail.map(element => {
        var data = {}
        if (element.length !== 3) {
            res.status(422).json(errors);
            return;
        }

        // var orderID = element[0];
        var productID = element[1];
        var quantity = element[2];
        // try to update each inventory, if any fail, don't create
        return inventories.getOneInventory(1, req).then(response => {
            if (response.result && response.result[0] && response.result[0].Quantity >= quantity) {
                data.quantity = response.result[0].Quantity - quantity;
                return inventories.updateOneInventory(productID, data, req).then(res => {
                }).catch(err => {
                    return Promise.reject('404');
                })
            } else {
                return Promise.reject('406');

            }
        }).then((ret) => {

        }).catch(err => {

            console.log(err);
            if (err === '404') {
                return Promise.reject('404').catch((err) => {
                    return err;
                });

            } else if (err === '406') {
                return Promise.reject('406').catch((err) => {
                    return err;
                });

            }

        })
    })).then(function (arrayOfValuesOrErrors) {
        arrayOfValuesOrErrors.map(err => {
            if (err === '404') {
                return res.status(404).send({
                    error: 'Inventory not found'
                });
            } else if (err === '406') {
                // TODO: restore inventory...
                return res.status(406).send({
                    error: 'Not enough item in the inventory'
                });
            }
        })
        req.getConnection(function (err, conn) {

            if (err) return next("Cannot Connect");
            conn.query('SELECT * FROM customer WHERE email=?', [req.query.email], function (err, response) {
                if (err) {
                    return next("Mysql error, check your query");
                } else if (response.length == 0) {
                    return res.status(404).send({
                        error: 'Customer email not found, make sure the email is input correctly.'
                    });
                } else {
                    var data = {
                        OrderID: null, // handling by mysql
                        Email: req.query.email,
                        OrderDate: MOMENT().format('YYYY-MM-DD HH:mm:ss.000'),
                        Status: 'placed',
                        CustomerID: response[0].ID,
                    };
                    conn.query("INSERT INTO Orders SET ? ", data, function (err, resp) {
                        if (err) {
                            console.log(err);
                            return next("Mysql error, check your query");
                        }
                        res.sendStatus(200);
                    });
                }
            });
        });
        return Promise.resolve();
        // handling of my array containing values and/or errors. 
    }).catch(function (err) {

        if (typeof erro !== 'undefined') {
            console.log(err);

        }
    });

});

var singleOrderRouter = router.route('/:id');

singleOrderRouter.get(function (req, res, next) {
    var orderID = req.params.id;

    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        conn.query('SELECT * FROM Orders WHERE OrderID=?', [orderID],
            function (err, response) {
                if (err) {
                    console.log(err);
                    return next("Mysql error, check your query");
                }
                // handling order not found
                if (response.length === 0) {
                    res.status(404).send('Order ID not found');
                } else {
                    res.json(response);
                }
            });
    });
});

// update an order
singleOrderRouter.put(function (req, res, next) {
    var id = req.params.id;
    var errors = req.validationErrors();
    if (errors) {
        res.status(422).json(errors);
        return;
    }

    //get data
    var data = {
        Status: req.body.status,
    };

    //inserting into mysql
    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        var query = conn.query("UPDATE Orders set ? WHERE OrderID = ?", [data, id], function (err, resp) {

            if (err) {
                console.log(err);
                return next("Mysql error, check your query");
            }
            if (resp.affectedRows === 0) {
                res.status(404).send({ error: 'Order ID not found, make sure it\'s input correctly.' });
                return;
            }
            res.status(200).send('Order was updated successfully!');
        });
    });
});

//delete data
singleOrderRouter.delete(function (req, res, next) {

    var id = req.params.id;

    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        var query = conn.query("DELETE FROM Orders WHERE OrderID = ? ", [id], function (err, resp) {

            if (err) {
                console.log(err);
                return next("Mysql error, check your query");
            }

            if (resp.affectedRows === 0) {
                res.status(404).send({ error: 'Order ID not found, make sure it\'s input correctly.' });
                return;
            }
            res.status(200).send('Order was deleted successfully!');
        });

    });
});
module.exports.router = router;