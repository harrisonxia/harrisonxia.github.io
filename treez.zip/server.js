var express = require('express'),
    path = require('path'),
    bodyParser = require('body-parser'),
    app = express(),
    expressValidator = require('express-validator');


app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true })); //support x-www-form-urlencoded
app.use(bodyParser.json());
app.use(expressValidator());

/*MySql connection*/
var connection = require('express-myconnection'),
    mysql = require('mysql');

app.use(

    connection(mysql, {
        host: 'localhost',
        user: 'root',
        password: 'Xcx1092_x',
        database: 'Treez',
        debug: false //set true if you wanna see debug logger
    }, 'request')

);

app.get('/', function (req, res) {
    res.send('Welcome');
});

var router = express.Router();
var inventories = require('./routes/inventories').router;
var orders = require('./routes/orders').router;


app.use('/inventories', inventories);
app.use('/orders', orders);

//start Server
var server = app.listen(3000, function () {

    console.log("Listening to port %s", server.address().port);

});
