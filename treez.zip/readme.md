# Treez Challenge

Some of the functionalities were not fully implemented due to time limit. I'll
explain in the enpoint section.

## The database is modelled as following:

`CREATE TABLE Customer (
     ID INT NOT NULL AUTO_INCREMENT,
     Email VARCHAR(40) NOT NULL UNIQUE,
     PRIMARY KEY (id)
);`

`CREATE TABLE Orders (
    OrderID INT NOT NULL AUTO_INCREMENT,
    Email VARCHAR(40),
    OrderDate TIMESTAMP NOT NULL,
    Status VARCHAR(30),
    CustomerID INT NOT NULL,
    PRIMARY KEY (OrderID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(ID),
    FOREIGN KEY (Email) REFERENCES Customer(Email)
);`

`CREATE TABLE Inventory (
    ProductID INT NOT NULL AUTO_INCREMENT,
    Name VARCHAR(40) NOT NULL,
    Price NUMERIC(10,1) NOT NULL,
    Description VARCHAR(255),
    Quantity INT NOT NULL,
    PRIMARY KEY (ProductID)
);`

`CREATE TABLE OrderDetail (
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Inventory(ProductID)
);`

## To run

- Go to `server.js` and change login info for the mysql server
- Load `init.sql` in mysql to initialize the database
- do `npm install` in terminal
- `npm start` to start the server

## Supported enpoints

1. Create inventory item
    - POST http://localhost:3000/inventories
2. Read all inventory items
GET http://localhost:3000/inventories
3. Read single inventory item
GET http://localhost:3000/inventories/1
4. Update inventory item
    - PUT http://localhost:3000/inventories/1
    - Example: `curl --location --request PUT 'http://localhost:3000/inventories/1' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'quantity=5'`
5. Delete inventory item
DELETE http://localhost:3000/inventories/1
6. Create order (will update inventory and do validation with inventory)
    - POST http://localhost:3000/orders
    - Example:
`curl --location --request POST 'localhost:3000/orders/?email=alex@gmail.com' \
--header 'Content-Type: application/json' \
--data-raw '{
	"OrderDetail": [[1,1,1], [1,1,2]]
}'`
7. Read all orders
GET http://localhost:3000/orders
8. Read single order
GET http://localhost:3000/orders/1
9. Update order
   - PUT (similar to POST, didn't implement full functionality due to time
   limit) http://localhost:3000/orders/1
   - Example: `curl --location --request PUT 'http://localhost:3000/orders/1' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'status=modified1'`
10. Delete order (similar to POST, didn't implement full functionality due to time
   limit)
DELETE http://localhost:3000/orders/1